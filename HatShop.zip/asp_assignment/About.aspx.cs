﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class About : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

                lblintro.Text = @"<h3>Letter to our customers</h3> <br>
       <h4> Dear Customer, <br>
        After many years in the hat business, we launched QualityHats.com. <br>
        Connecting with customers around the world was great fun. 
        Today, although the promise of that early Internet sometimes is forgotten, here the same values prevail. 
        If you are looking for authenticity, you won't find a better place to shop. 
        These days, where it’s difficult distinguishing the substantive from the virtual, Quality Hats shop is all about content.
        This includes how we conduct ourselves as merchants - as a family business our hallmark has always been service – to our site content, and, of course, our products. 
        The quality, prices, and breadth of selection of our headwear is simply second to none. <br><br>

        Thanks for your patronage <br><br>

        Sincerely, <br>
        Elena Shuvaeva<br>
        QualityHats.com <br><br> </h4>"
        ;
                lblDesc.Text = @"<h4>Hats, caps & berets from around the world.
        Shop our growing selection of iconic brands, styles and colors. 
        Quality Hats is a retail store in Auckland, New Zealand. We launched our website, QualityHats.com, 
        and have been thrilling hat lovers ever since. Are you looking to buy hats?
        Rest assured, you've come to the right place! 
        Our aim is to have the greatest selection of hats and head wear online,
        while offering our customers the best possible prices and service.</h4> ";
    }
}