﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLayer;
using HatHelpers;

public partial class MasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        InterfacePrepare();


            btnLogout.Click += new EventHandler(btnLogout_Click);
            btnLogIn.Click +=new EventHandler(btnLogIn_Click);
            btnSearch.Click += new EventHandler(btnSearch_Click);

            if (Session[PageHelper.CURRENT_USER] != null)
            {
                btnLogIn.Visible = false;
                return;
            }
            btnLogIn.Visible = true;
            
            
        
    }

    private void btnSearch_Click(object sender, EventArgs e)
    {
        string search = new HtmlString(tbxSearch.Text).ToHtmlString();

        Response.Redirect("~/Products.aspx?" + PageHelper.PAR_QUESTION + "=" + search);

    }

    private void btnLogIn_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Login.aspx");
    }

    public void btnLogout_Click(object sender, EventArgs e)
    {
        Session.Abandon();
        (System.Web.Security.Roles.Provider as HatShopRoleProvider).RoleUser = null;

        lblAdmin.Visible = false;
        ddlAdminShow.Visible = false;
        lblUsername.Text = "Hello!";
        btnLogout.Visible = false;
        Response.Redirect("~/Home.aspx");
    }

    private void InterfacePrepare()
    {

        btnLogout.Visible = false;
        lblAdmin.Visible = false;
        lblUsername.Text = "Hello";
        ddlAdminShow.Visible = false;

        if (Session[PageHelper.CURRENT_USER] != null)
        {
            HatHelpers.User currentUser = Session[PageHelper.CURRENT_USER] as HatHelpers.User;
            if (currentUser.IsAuthorised)
            {
                string firstName = currentUser.FirstName;
                string lastName = currentUser.LastName;
                string address = currentUser.Address;
                string email = currentUser.Email;

                lblUsername.Text = firstName + " " + lastName;
                btnLogout.Visible = true;

                if (currentUser.UserAccessType == HatHelpers.UserAccess.Admin)
                {
                    lblAdmin.Visible = true;
                    ddlAdminShow.Visible = true;
                }

            }
        }

       



    }

}
