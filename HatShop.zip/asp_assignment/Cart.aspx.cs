﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HatHelpers;
using System.Data;

public partial class Cart : PageHelper
{

    private ShoppingCart _cart;

    protected void Page_Load(object sender, EventArgs e)
    {
        //event handlers
        btnCheckout.Click += new EventHandler(btnCheckout_Click);
        btnClear.Click += new EventHandler(btnClear_Click);

        GrvShoppingCart.RowDeleting += new GridViewDeleteEventHandler(GrvShoppingCart_RowDeleting);
        GrvShoppingCart.RowCommand += new GridViewCommandEventHandler(GrvShoppingCart_RowCommand);
        lblToAccountLink.Visible = false;
        
        if (Session[SHOPPING_CART] == null)
        {
            Session[SHOPPING_CART] = new ShoppingCart();
        }

        _cart = Session[SHOPPING_CART] as ShoppingCart;
        if (!Page.IsPostBack)
        {
            this.SetData();
        }
    }

    //change quantity

    private void GrvShoppingCart_RowCommand(object sender, GridViewCommandEventArgs e)
    {

        if (e.CommandName == "Decrease" || e.CommandName == "Increase")
        {
            int rowIndex = Convert.ToInt32(e.CommandArgument);
            GridViewRow item = GrvShoppingCart.Rows[rowIndex];

            var quantityControl = (item.FindControl("lblGrvQuantity") as Label);
            string quantityStr = quantityControl.Text;
            int quantity;

            if (!Int32.TryParse(quantityStr, out quantity))
            {
                return;
            }

            if (e.CommandName == "Decrease")
            {
                if (quantity < 2)
                {
                    return;
                }
                quantity--;
            }

            if (e.CommandName == "Increase")
            {
                quantity++;
            }

            decimal unitPrice = Convert.ToDecimal(_cart.Content.Rows[rowIndex][ShoppingCart.FIELD_UNIT_PRICE].ToString());

            _cart.Content.Rows[rowIndex][ShoppingCart.FIELD_QUANTITY] = quantity.ToString();
            _cart.Content.Rows[rowIndex][ShoppingCart.FIELD_SUB_TOTAL] = quantity * unitPrice;
            SetData();
        }
    }


    //delete rows from the cart
    private void GrvShoppingCart_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

        _cart.Content.Rows.RemoveAt(e.RowIndex);
        SetData();
    }


    //clear cart
    private void btnClear_Click(object sender, EventArgs e)
    {
        _cart.Content.Clear();
        SetData();
    }

    //checkout
    private void btnCheckout_Click(object sender, EventArgs e)
    {

        if (Session[CURRENT_USER] == null || !((HatHelpers.User)Session[CURRENT_USER]).IsAuthorised)
        {
            Response.Redirect("~/Login.aspx");
        }
        else
        {
            string customerID = (Session[CURRENT_USER] as HatHelpers.User).UserID;

            if (_cart.Content.Rows.Count > 0)
            {
                ErrorToken token;
                string message = BusinessLayer.AddOrder(customerID, _cart, out token);

                if (token != null)
                {
                    Session[PageHelper.USER_EXCEPTION] = token;
                    Response.Redirect("~/ErrorPage.aspx");
                }

                if (message != string.Empty)
                {
                    lblMessage.Text = message;
                    return;
                }

                _cart.Content.Clear();
                this.SetData();
                lblToAccountLink.Visible = true;
                lblMessage.Text = "Thank you for your order! You can see the shipping status on " + lblToAccountLink.Text;
            }
            else
            {
                lblMessage.Text = "You have not ordered a hat yet.Please, see Our Products page or Use Search by Hat Name. Thank you!";
            }
        }
    }

    //show  cart content (from the Shoopping cart class)
    private void SetData()
    {
        GrvShoppingCart.DataSource = _cart.Content;
        GrvShoppingCart.DataBind();

        double total = _cart.Total;
        double totalGst = total + (total * 0.15);
        lblTotalpriceValue.Text = " $ " + totalGst.ToString();
        double gst = total * 0.15;
        lblGstValue.Text = " $ "+ gst.ToString();
    }


   
}