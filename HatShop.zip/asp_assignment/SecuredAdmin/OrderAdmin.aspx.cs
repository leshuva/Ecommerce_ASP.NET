﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLayer;
using HatHelpers;
using System.Data.OleDb;
using System.Data;
public partial class SecuredAdmin_OrderAdmin : PageHelper
{
    protected void Page_Load(object sender, EventArgs e)
    {

        //Event handlers
        GrVOrders.RowEditing += new GridViewEditEventHandler(GrVOrders_RowEditing);
        GrVOrders.RowUpdating += new GridViewUpdateEventHandler(GrVOrders_RowUpdating);
        GrVOrders.RowCancelingEdit += new GridViewCancelEditEventHandler(GrVOrders_RowCancelingEdit);
        GrVOrders.RowDataBound += new GridViewRowEventHandler(GrVOrders_RowDataBound);

        GrVOrders.PageIndexChanging += new GridViewPageEventHandler(GrVOrders_PageIndexChanging);

        GrVOrders.AutoGenerateSelectButton = true;
        GrVOrders.SelectedIndexChanged += new EventHandler(GrVOrders_SelectedIndexChanged);
        lblMessage.Text = "";
        if (!this.IsPostBack)
        {

            
            SetData();

        }


    }
    
    private void GrVOrders_SelectedIndexChanged(object sender, EventArgs e)
    {

        GridViewRow selectedRow = GrVOrders.SelectedRow;

        string orderID = (selectedRow.FindControl("lblGrvOrderId") as Label).Text;

        DataTable orderDetails = BusinessLayer.LoadOrderDetails(orderID);


        GrvOrderDetails.DataSource = orderDetails;
        GrvOrderDetails.DataBind();
        GrvOrderDetails.Visible = true;
    }

    //Databound for Gridview
    private void GrVOrders_RowDataBound(object sender, GridViewRowEventArgs e)
    {

        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            if ((e.Row.RowState & DataControlRowState.Edit) > 0)
            {
                OrderStatusEditDropDownList(e.Row);
            }
        }

    }

    //Edit status

    private void OrderStatusEditDropDownList(GridViewRow row)
    {
        DropDownList ddList = (DropDownList)row.FindControl("ddlOrderStatus");
        //bind dropdown-list
        DataTable dt = BusinessLayer.LoadStatus();
        ddList.DataSource = dt;
        ddList.DataTextField = "OrderStatus";
        ddList.DataValueField = "StatusID";
        ddList.DataBind();

        DataRowView dr = row.DataItem as DataRowView;
        ddList.SelectedValue = dr["OrderStatus"].ToString();

    }

    //Cancel to edit
    private void GrVOrders_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GrVOrders.EditIndex = -1;
        SetData();
    }
    //Update row
    private void GrVOrders_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        GridViewRow row = GrVOrders.Rows[e.RowIndex];
        Control cnStatus = row.FindControl("ddlOrderStatus");

        Control cnOrderId = row.FindControl("lblGrvOrderId");
      

        string orderId = (cnOrderId as Label).Text;
      
        string status = (cnStatus as DropDownList).SelectedValue;
        BusinessLayer.UpdateOrder(orderId, status);
        GrVOrders.EditIndex = -1;
        SetData();
    }
    //Edit mode
    private void GrVOrders_RowEditing(object sender, GridViewEditEventArgs e)
    {
        GrVOrders.EditIndex = e.NewEditIndex;
        SetData();
    }

    //Data set from Business logic


    public void SetData()
    {
        DataTable dtableOrder = BusinessLayer.LoadOrders();
        GrVOrders.DataSource = dtableOrder;

        GrVOrders.DataBind();

        GrVOrders.AllowPaging = true;
        GrVOrders.PageSize = 10;
        GrVOrders.AutoGenerateEditButton = true;
        GrVOrders.DataSource = dtableOrder;

        GrVOrders.DataBind();
        GrvOrderDetails.Visible = false;

    }

    //Paging
    public void GrVOrders_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

        if (GrVOrders.EditIndex != -1)
        {
            // Use the Cancel property to cancel the paging operation.
            e.Cancel = true;

            // Display an error message.
            int newPageNumber = e.NewPageIndex;
            lblMessage.Text = "Please update the record before moving to another page.";
        }
        else
        {
            // Clear the error message.
            lblMessage.Text = "";
            GrVOrders.PageIndex = e.NewPageIndex;
            SetData();
        }

    }
}