﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using BusinessLayer;
using HatHelpers;

public partial class SupplierAdmin : PageHelper
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //Initialise event handlers
       
        GrVSuppliers.RowEditing += new GridViewEditEventHandler(GrVSuppliers_RowEditing);
        GrVSuppliers.RowUpdating += new GridViewUpdateEventHandler(GrVSuppliers_RowUpdating);
        GrVSuppliers.RowCancelingEdit += new GridViewCancelEditEventHandler(GrVSuppliers_RowCancelingEdit);
        GrVSuppliers.PageIndexChanging += new GridViewPageEventHandler(GrVSuppliers_PageIndexChanging);
        lblMessage.Text = "";

       

        if (!this.IsPostBack)
        {
            pnlAddSuppl.Visible = false;
            SetData();

        }

    }

    //Load data from Business logic
    private void SetData()
    {
        DataTable dtableSupplier = BusinessLayer.LoadSuppliers();
        ViewState["CurrentTable"] = dtableSupplier;
        GrVSuppliers.AllowPaging = true;
        GrVSuppliers.PageSize = 5;
        GrVSuppliers.AutoGenerateEditButton = true;
        GrVSuppliers.DataSource = dtableSupplier;

        GrVSuppliers.DataBind();

    }

    //Row Modify
    private void GrVSuppliers_RowEditing(object sender, GridViewEditEventArgs e)
    {
        GrVSuppliers.EditIndex = e.NewEditIndex;
        SetData();

    }

    //Save new info , update
    private void GrVSuppliers_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        GridViewRow row = GrVSuppliers.Rows[e.RowIndex];
        Control cnSupplierId = row.FindControl("lblGrvSupplierId");
        Control cnName = row.FindControl("txtGrvSupplierName");
        Control cnWorkPhone = row.FindControl("txtGrvWorkPhone");
        Control cnMobile = row.FindControl("txtGrvMobilePhone");
        Control cnEMail = row.FindControl("txtGrvEMail");
        
        string newSupplierID = (cnSupplierId as Label).Text;
        string newName = (cnName as TextBox).Text;
        string newWorkPhone = (cnWorkPhone as TextBox).Text;
        string newMobile = (cnMobile as TextBox).Text;
        string newemail = (cnEMail as TextBox).Text;

        if (ValidationSupplier(newName, newWorkPhone, newMobile, newemail))
        {
            BusinessLayer.UpdateSupplier(newSupplierID, newName, newWorkPhone, newMobile, newemail);
            GrVSuppliers.EditIndex = -1;
            SetData();
        }
        
       
    }
    //Cancel to modify
    private void GrVSuppliers_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GrVSuppliers.EditIndex = -1;
        SetData();

    }
    //Paging
    private void GrVSuppliers_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

        if (GrVSuppliers.EditIndex != -1)
        {
            // Use the Cancel property to cancel the paging operation.
            e.Cancel = true;

            // Display an error message.
            int newPageNumber = e.NewPageIndex;
            lblMessage.Text = "Please update the record before moving to another page.";
        }
        else
        {
            // Clear the error message.
            lblMessage.Text = "";
            GrVSuppliers.PageIndex = e.NewPageIndex;
            SetData();
        }
    }

    //Panel to add visible
    protected void Add(object sender, EventArgs e)
    {

        pnlAddSuppl.Visible = true;

    }

    //Add new supplier
    protected void AddSupplier( object sender, EventArgs e){
     
     Control csuppName = (tblSupplAdd.FindControl("txtSuppNameAdd") as TextBox);
     Control cworkPhone = (tblSupplAdd.FindControl("txtWorkPhoneAdd") as TextBox);
     Control cmobile = (tblSupplAdd.FindControl("txtMobileAdd") as TextBox);
     Control cemail = (tblSupplAdd.FindControl("TextEmailAdd") as TextBox);

     string suppName = (csuppName as TextBox).Text;
     string workPhone = (cworkPhone as TextBox).Text;
     string mobile = (cmobile as TextBox).Text;
     string email = (cemail as TextBox).Text;
    if( ValidationSupplier(suppName, workPhone, mobile, email))
    {
     BusinessLayer.AddSupplier(suppName, workPhone, mobile, email);
     SetData();
     lblMessage.Text = "You have added the supplier " + txtSuppNameAdd.Text+ "!";
     pnlAddSuppl.Visible = false;
    }
    }

    //Validation new info for Supplier

    public bool ValidationSupplier(string name, string workPhone, string mobile, string email)
    {
        int workphone;
        int mobilePhone;
        int atPosition = email.IndexOf('@');
        if (name.Length == 0||workPhone.Length==0||email.Length==0)
        {
            lblMessage.Text = "Fill please all the required fields (name, workphone and email)";
            return false;
        
        }
        else
        if(!Int32.TryParse(workPhone, out workphone))
        {
            lblMessage.Text="Your phonenumber is invalid, type numbers, please";
            return false;
        }
        else
        if (mobile.Length != 0 && (!Int32.TryParse(mobile, out mobilePhone)))
        {

            lblMessage.Text = "Your mobile phonenumber is invalid, type numbers, please";
            return false;
        }
        else
        if (atPosition == -1)
        {
            lblMessage.Text = "Your email must contain @ symbol";
            return false;
        }

        else
        { return true; }

    }
}