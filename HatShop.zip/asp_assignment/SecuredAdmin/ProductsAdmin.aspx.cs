﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLayer;
using HatHelpers;
using System.Data.OleDb;
using System.Data;

public partial class ProductsAdmin : PageHelper
{

    protected void Page_Load(object sender, EventArgs e)
    {
        //Event handlers
        btnAddProduct.Click += new EventHandler(btnAddProduct_Click);
        btnCreateCategory.Click += new EventHandler(btnCreateCategory_Click);

        GrVProducts.RowEditing += new GridViewEditEventHandler(GrVProducts_RowEditing);
        GrVProducts.RowUpdating += new GridViewUpdateEventHandler(GrVProducts_RowUpdating);
        GrVProducts.RowCancelingEdit += new GridViewCancelEditEventHandler(GrVProducts_RowCancelingEdit);

        GrVProducts.RowDataBound += new GridViewRowEventHandler(GrVProducts_RowDataBound);
        GrVProducts.PageIndexChanging += new GridViewPageEventHandler(GrVProducts_PageIndexChanging);
        GrVProducts.RowDeleting +=new GridViewDeleteEventHandler(GrVProducts_RowDeleting);

        lblMessage.Text = "";
        if (!this.IsPostBack)
        {

            LoadCategoriesAndSuppliers();
            SetData();
        }

    }

    //Paging
    private void GrVProducts_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        // Cancel the paging operation if the user attempts to navigate
        // to another page while the GridView control is in edit mode. 
        if (GrVProducts.EditIndex != -1)
        {
            // Use the Cancel property to cancel the paging operation.
            e.Cancel = true;

            // Display an error message.
            int newPageNumber = e.NewPageIndex;
            lblMessage.Text = "Please update the record before moving to another page.";
        }
        else
        {
            // Clear the error message.
            lblMessage.Text = "";
            GrVProducts.PageIndex = e.NewPageIndex;
            SetData();
        }

    }

    //Cancel to update
    private void GrVProducts_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GrVProducts.EditIndex = -1;
        SetData();
    }

    //Show data in Gridview
    private void GrVProducts_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            if ((e.Row.RowState & DataControlRowState.Edit) > 0)
            {
                CategoryEditDropDownList(e.Row);
                
                SupplierEditDropDownList(e.Row);
            }
        }
    }

    //Update info in row

    private void GrVProducts_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {

        GridViewRow row = GrVProducts.Rows[e.RowIndex];

        Control cnId = row.FindControl("lblGrvProductId");
        Control cnProductName = row.FindControl("txtGrvProductName");
        Control cnDescription = row.FindControl("txtGrvDescription");
        Control cnUnitPrice = row.FindControl("txtGrvPrice");
       
        Control cnCategory = row.FindControl("ddlCategoryEdit");
        Control cnSupplier = row.FindControl("ddlSupplierEdit");
        FileUpload FileUpload1 = (FileUpload)GrVProducts.Rows[e.RowIndex].FindControl("FileUpload1");
        string productId = (cnId as Label).Text;
        string newProductName = (cnProductName as TextBox).Text;
        string newDescription = (cnDescription as TextBox).Text;
        string newUnitPrice = (cnUnitPrice as TextBox).Text;
      
        string newCategory = (cnCategory as DropDownList).SelectedValue;
        string newSupplier = (cnSupplier as DropDownList).SelectedValue;
        string Imgpath = "~/uploads/images/";


        if (FileUpload1.HasFile)
        {
           
                Imgpath += FileUpload1.FileName;
                //save image in folder
                FileUpload1.SaveAs(MapPath(Imgpath));
            
        }
        else
        {
            // use previous user image if new image is not changed
            Image img = (Image)GrVProducts.Rows[e.RowIndex].FindControl("imgPicture");
            Imgpath = img.ImageUrl;
        }

        if (!ValidateProduct(newProductName, newDescription, newUnitPrice))
        { return; }
        else
        {
            ErrorToken token;
            BusinessLayer.UpdateProduct(productId, newProductName, newDescription, newUnitPrice, newCategory, newSupplier, Imgpath, out token);

            if (token != null)
            {
                Session[USER_EXCEPTION] = token;
                Response.Redirect("~/ErrorPage.aspx");
            }

            GrVProducts.EditIndex = -1;
            SetData();
        }

    }
    //Modify info in row
    private void GrVProducts_RowEditing(object sender, GridViewEditEventArgs e)
    {
        GrVProducts.EditIndex = e.NewEditIndex;
        //gridviewBind();// your gridview binding function

        SetData();
    }
    //Validation product
    public bool ValidateProduct(string productName, string desc, string price)
    {

        double Price;
        if (productName.Length == 0)
        {
            lblMessage.Text = "Type please the Product Name";
            return false;
        }
        else
            if (price.Length == 0)
            {
                lblMessage.Text = "Type please the Product Price";
                return false;
            }
            else
                if (!double.TryParse(price, out Price))
                {
                    lblMessage.Text = "Invalid price, type number please";
                    return false;
                }

                else
                {
                    return true;
                }
    }
    //Validation Category
    public bool ValidateCategory(string name, string desc)
    {
        if (name.Length == 0)
        {
            lblMessage.Text = "You cannot add category without name";
            return false;
        }
        else
        {
            return true;
        }


    }


    //Add Product button
    protected void btnAddProduct_Click(object sender, EventArgs e) //validation price
    {
        if (!ValidateProduct(txtProductName.Text, txtDescription.Text, txtPrice.Text))
        { return; }

        if (!ValidatePicture())
        {
            lblMessage.Text = "You file is not in correct format.";
            return;
        }

        UploadProduct();

    }
    //Create Category
    protected void btnCreateCategory_Click(object sender, EventArgs e)
    {
        if (!ValidateCategory(txtNewCategory.Text, txtDescription.Text))
        {
            return;
        }
        else
        {
            BusinessLayer.SaveCategory(txtNewCategory.Text, txtCatDescr.Text);
            LoadCategoriesAndSuppliers();
        }

    }

    //new productid (not used here)

    private void DisplayNewProductId()
    {

        int newProductId = BusinessLayer.GetNewProductId();
        lblOutput.Text = "<h3> You added the product " + txtProductName.Text + " Successfully!</h3>";
        lblProductId.Text = "<h3> ProductId is " + newProductId.ToString() + "</h3>";


    }


    public void EmptyFields()
    {
        txtProductName.Text = "";
        txtDescription.Text = "";

        txtPrice.Text = "";
        txtNewCategory.Text = "";
        txtCatDescr.Text = "";
        ddlCategory.SelectedValue = "";
        ddlSupplier.SelectedValue = "";

    }

    //Databound for Category and Suppliers dropdown list
    public void LoadCategoriesAndSuppliers()
    {
        DataTable dtCategories = BusinessLayer.LoadCategories();
        DataTable dtSuppliers = BusinessLayer.LoadSuppliers();
 
        ddlCategory.DataSource = dtCategories;
        ddlSupplier.DataSource = dtSuppliers;
 
        ddlCategory.DataTextField = "CategoryName";
        ddlCategory.DataValueField = "CategoryId";
        ddlCategory.DataBind();

        ddlSupplier.DataTextField = "SupplierName";
        ddlSupplier.DataValueField = "SupplierId";
        ddlSupplier.DataBind();



    }

    ///Validation picture

    private bool ValidatePicture()
    {
        if
            ((fillmyfile.HasFile) &&
       
            (fillmyfile.PostedFile.ContentType == "image/gif" )||
            (fillmyfile.PostedFile.ContentType == "image/jpg") ||
             (fillmyfile.PostedFile.ContentType == "image/jpeg" )||
            (fillmyfile.PostedFile.ContentType == "image/png")

            )
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    //Add product
    private void UploadProduct()
    {
        try
        {
            // By this time chosen file is validated by method ValidatePicture
            string myFileName = fillmyfile.FileName;

            ErrorToken token;

            //check the file first
            BusinessLayer.SaveProducts(txtProductName.Text, txtDescription.Text, txtPrice.Text, ddlCategory.SelectedValue, ddlSupplier.SelectedValue, "~/uploads/images/" + myFileName, out token);
            if (token != null)
            {
                Session[USER_EXCEPTION] = token;
                Response.Redirect("~/ErrorPage.aspx");
            }
            ////save picture in the folder
            fillmyfile.SaveAs(Server.MapPath("~/uploads/images/") + myFileName);
            lblMessage.Text = "You have added a new product " + txtProductName.Text + " successfully!<br/>You can use SEARCH by HAT NAME to see it in the Catalogue.<br/>If you want to modify product please use the table at the bottom of this page";
        }
        catch (Exception ex)
        {
            lblMessage.Text = "There is a problem: " + ex.GetType() + " Message: " + ex.Message;
        }
    }


    //Load data to GridView
    private void SetData()
    {
        ErrorToken token;

        DataTable dtableProduct = BusinessLayer.LoadAllProductDetails(out token);
        ViewState["CurrentTable"] = dtableProduct;
        GrVProducts.AllowPaging = true;
        GrVProducts.PageSize = 5;
        GrVProducts.AutoGenerateEditButton = true;
        GrVProducts.DataSource = dtableProduct;

        GrVProducts.DataBind();

    }


    protected void BtnModifyProduct_Click(object sender, EventArgs e)
    {

        var data = GrVProducts.DataSource;

        SetData();

    }

    //To Choose  Category in Edit Mode
    private void CategoryEditDropDownList(GridViewRow row)
    {
        DropDownList ddList = (DropDownList)row.FindControl("ddlCategoryEdit");
        //bind dropdown-list
        DataTable dt = BusinessLayer.LoadCategories();
        ddList.DataSource = dt;
        ddList.DataTextField = "CategoryName";
        ddList.DataValueField = "CategoryName";
        ddList.DataBind();

        DataRowView dr = row.DataItem as DataRowView;
        ddList.SelectedValue = dr["CategoryName"].ToString();

    }

    //To Choose  Supplier in Edit Mode

    private void SupplierEditDropDownList(GridViewRow row)
    {
        DropDownList ddList = (DropDownList)row.FindControl("ddlSupplierEdit");
        //bind dropdown-list
        DataTable dt = BusinessLayer.LoadSuppliers();
        ddList.DataSource = dt;
        ddList.DataTextField = "SupplierName";
        ddList.DataValueField = "SupplierName";
        ddList.DataBind();

        DataRowView dr = row.DataItem as DataRowView;
        ddList.SelectedValue = dr["SupplierName"].ToString();

    }

    //Delete product (hide from interface)
    private void GrVProducts_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

        int pageIndex = GrVProducts.PageIndex;
        int recordsPerPage = GrVProducts.PageSize;

        int currentIndex = pageIndex * recordsPerPage + e.RowIndex;

        DataRow row = (ViewState["CurrentTable"] as DataTable).Rows[currentIndex];

        string productId = row["ProductID"].ToString();
        ErrorToken token;

        BusinessLayer.DeleteProduct(productId, out token);
        if (token != null)
        {
            Session[PageHelper.USER_EXCEPTION] = token;
            Response.Redirect("~/ErrorPage.aspx");
        }

        SetData();
    }


}