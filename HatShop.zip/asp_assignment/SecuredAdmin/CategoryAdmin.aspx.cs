﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using BusinessLayer;
using HatHelpers;

public partial class SecuredAdmin_CategoryAdmin : PageHelper
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //Initialize Gridview event handlers
        GrVCategory.RowEditing += new GridViewEditEventHandler(GrVCategory_RowEditing);
        GrVCategory.RowUpdating += new GridViewUpdateEventHandler(GrVCategory_RowUpdating);
        GrVCategory.RowCancelingEdit += new GridViewCancelEditEventHandler(GrVCategory_RowCancelingEdit);
        GrVCategory.PageIndexChanging += new GridViewPageEventHandler(GrVCategory_PageIndexChanging);
        lblMessage.Text = "";

        if (!this.IsPostBack)
        {
            pnlAddCategory.Visible = false; //hide the panel to add category
            SetData();  //loads all th data from business logic

        }

    }


    private void SetData()
    {
        DataTable dtableCategory = BusinessLayer.LoadCategories();
        ViewState["CurrentTable"] = dtableCategory;
        GrVCategory.AllowPaging = true;
        GrVCategory.PageSize = 5;
        GrVCategory.AutoGenerateEditButton = true;
        GrVCategory.DataSource = dtableCategory;

        GrVCategory.DataBind();

    }

    //Modify info in Gridview
    private void GrVCategory_RowEditing(object sender, GridViewEditEventArgs e)
    {
        GrVCategory.EditIndex = e.NewEditIndex;
        SetData();

    }
    //Update info on GridView
    private void GrVCategory_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        GridViewRow row = GrVCategory.Rows[e.RowIndex];
        Control cnCategoryId = row.FindControl("lblGrvCategoryId");
        Control cnName = row.FindControl("txtGrvCategoryName");
        Control cnDescription = row.FindControl("txtGrvDescription");


        string newCategoryID = (cnCategoryId as Label).Text;
        string newName = (cnName as TextBox).Text;
        string newDescription = (cnDescription as TextBox).Text;


        if (ValidationCategory(newName, newDescription))
        {
            BusinessLayer.UpdateCategory(newCategoryID, newName, newDescription);
            GrVCategory.EditIndex = -1;
            SetData();
        }


    }
    //Cancel to Update
    private void GrVCategory_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GrVCategory.EditIndex = -1;
        SetData();

    }
    //Paging
    private void GrVCategory_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

        if (GrVCategory.EditIndex != -1)
        {
            // Use the Cancel property to cancel the paging operation.
            e.Cancel = true;

            // Display an error message.
            int newPageNumber = e.NewPageIndex;
            lblMessage.Text = "Please update the record before moving to another page.";
        }
        else
        {
            // Clear the error message.
            lblMessage.Text = "";
            GrVCategory.PageIndex = e.NewPageIndex;
            SetData();
        }
    }

    //to add Category show Panel
    protected void Add(object sender, EventArgs e)
    {

        pnlAddCategory.Visible = true;

    }
    //Save Category
    protected void AddCategory(object sender, EventArgs e)
    {

        Control csuppName = (tblCategoryAdd.FindControl("txtCategoryNameAdd") as TextBox);
        Control cworkPhone = (tblCategoryAdd.FindControl("txtDescriptionAdd") as TextBox);

        string catName = (csuppName as TextBox).Text;
        string description = (cworkPhone as TextBox).Text;

        if (ValidationCategory(catName, description))
        {
            BusinessLayer.SaveCategory(catName, description);
            SetData();
            lblMessage.Text = "You have added the Category " + txtCategoryNameAdd.Text + "!";
            pnlAddCategory.Visible = false;
        }
    }

    //Validation new category before save

    public bool ValidationCategory(string name, string description)
    {

        if (name.Length == 0)
        {
            lblMessage.Text = "Fill please the required fields Category Name";
            return false;

        }


        else
        { return true; }

    }
}