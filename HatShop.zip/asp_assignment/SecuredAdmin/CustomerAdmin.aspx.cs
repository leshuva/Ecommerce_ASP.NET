﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class CustomerAdmin : PageHelper
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //Initisialise event handlers
        GrVCustomers.RowEditing += new GridViewEditEventHandler(GrVCustomers_RowEditing);
        GrVCustomers.RowUpdating += new GridViewUpdateEventHandler(GrVCustomers_RowUpdating);
        GrVCustomers.RowCancelingEdit += new GridViewCancelEditEventHandler(GrVCustomers_RowCancelingEdit);
        GrVCustomers.PageIndexChanging += new GridViewPageEventHandler(GrVCustomers_PageIndexChanging);
        lblMessage.Text = "";

        BtnAddCustomer.Click += new EventHandler(BtnAddCustomer_Click);
        if (!this.IsPostBack)
        {
            pnlAddCust.Visible = false; //hide panel
            SetData();

        }

    }

    //load data from business logic
    private void SetData()
    {
        DataTable dtableCustomer = BusinessLayer.LoadCustomers();
        ViewState["CurrentTable"] = dtableCustomer;
        GrVCustomers.AllowPaging = true;
        GrVCustomers.PageSize = 10;
        GrVCustomers.AutoGenerateEditButton = true;
        GrVCustomers.DataSource = dtableCustomer;
        GrVCustomers.DataBind();

    }

    //Modify info in the row

    private void GrVCustomers_RowEditing(object sender, GridViewEditEventArgs e)
    {
        GrVCustomers.EditIndex = e.NewEditIndex;
        SetData();

    }

    //Save new info in the row
    private void GrVCustomers_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        GridViewRow row = GrVCustomers.Rows[e.RowIndex];
        Control cnCustomerId = row.FindControl("lblGrvCustomerId");
        Control cnFirstName = row.FindControl("txtGrvFirstName");
        Control cnLastName = row.FindControl("txtGrvLastName");
        Control cnHomePhone = row.FindControl("txtGrvHomePhone");
        Control cnMobile = row.FindControl("txtGrvMobilePhone");
        Control cnEMail = row.FindControl("txtGrvEmail");
        Control cnAddress = row.FindControl("txtGrvAddress");
        Control cnLogin = row.FindControl("txtGrvLogin");
        Control cnPassword = row.FindControl("txtGrvPassword");
        Control cnAccess = row.FindControl("txtGrvAccessType");
        Control cnAccountEnabled = row.FindControl("txtGrvAccountEnabled");

        string newcustomerID = (cnCustomerId as Label).Text;
        string newfirstName = (cnFirstName as TextBox).Text;
        string newlastName = (cnLastName as TextBox).Text;
        string newhomePhone = (cnHomePhone as TextBox).Text;
        string newmobile = (cnMobile as TextBox).Text;
        string newemail = (cnEMail as TextBox).Text;
        string newaddress = (cnAddress as TextBox).Text;
        string newlogin = (cnLogin as TextBox).Text;
        string newpassword = (cnPassword as TextBox).Text;
        string newaccessType = (cnAccess as TextBox).Text;
        string newaccountEnable = (cnAccountEnabled as TextBox).Text;
        if (!((newaccountEnable == "Yes") || (newaccountEnable == "No")))
        {
            lblMessage.Text = "AccountEnabled field must be either 'Yes' or 'No'";
            return;
        }
        else
            if (!((newaccessType == "Admin") || (newaccessType == "Customer")))
            {
                lblMessage.Text = "AccessType field must be either 'Admin' or 'Customer'";
                return;
            }
            else if (ValidationCustomer(newfirstName, newlastName, newhomePhone, newmobile, newemail, newaddress, newlogin, newpassword))
            {
                BusinessLayer.UpdateCustomer(newcustomerID, newfirstName, newlastName, newhomePhone, newmobile, newemail, newaddress, newlogin, newpassword, newaccessType, newaccountEnable);
                GrVCustomers.EditIndex = -1;
                SetData();
            }
    }

    //Cancel to update
    private void GrVCustomers_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GrVCustomers.EditIndex = -1;
        SetData();

    }

    //Paging
    private void GrVCustomers_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

        if (GrVCustomers.EditIndex != -1)
        {
            // Use the Cancel property to cancel the paging operation.
            e.Cancel = true;

            // Display an error message.
            int newPageNumber = e.NewPageIndex;
            lblMessage.Text = "Please update the record before moving to another page.";
        }
        else
        {
            // Clear the error message.
            lblMessage.Text = "";
            GrVCustomers.PageIndex = e.NewPageIndex;
            SetData();
        }
    }

    //Panel to add customer
    protected void Add(object sender, EventArgs e)
    {

        pnlAddCust.Visible = true;
    }
    //Add new Customer by Admin
    private void BtnAddCustomer_Click(object sender, EventArgs e)
    {
        Control cnFirstName = tblCustAdd.FindControl("txtFirstNameAdd");
        Control cnLastName = tblCustAdd.FindControl("txtLastNameAdd");
        Control cnHomePhone = tblCustAdd.FindControl("txtHomePhoneAdd");
        Control cnMobile = tblCustAdd.FindControl("txtMobileAdd");
        Control cnEmail = tblCustAdd.FindControl("txtEmailAdd");
        Control cnAddress = tblCustAdd.FindControl("txtAddressAdd");
        Control cnLogin = tblCustAdd.FindControl("txtLoginAdd");
        Control cnPassword = tblCustAdd.FindControl("txtPasswordAdd");

        string newFirstname = (cnFirstName as TextBox).Text;
        string newLastName = (cnLastName as TextBox).Text;
        string newHomePhone = (cnHomePhone as TextBox).Text;
        string newMobile = (cnMobile as TextBox).Text;
        string newEmail = (cnEmail as TextBox).Text;
        string newAddress = (cnAddress as TextBox).Text;
        string newLogin = (cnLogin as TextBox).Text;
        string newPassword = (cnPassword as TextBox).Text;
        if (ValidationCustomer(newFirstname, newLastName, newHomePhone, newMobile, newEmail, newAddress, newLogin, newPassword))
        {
            BusinessLayer.AddCustomer(newFirstname, newLastName, newHomePhone, newMobile, newEmail, newAddress, newLogin, newPassword);
            SetData();
            lblMessage.Text = "You have added a new user!";
            pnlAddCust.Visible = false;
        }
    }
    //Validation new info for Customer
    private bool ValidationCustomer(string first, string last, string phone, string mobile, string email, string address, string login, string password)
    {

        int homephone, mobilephone;
        int atplace = email.IndexOf('@');
        if ((first.Length == 0) || (last.Length == 0) || (phone.Length == 0) || (email.Length == 0) || (address.Length == 0) || (login.Length == 0) || (password.Length == 0))
        {
            lblMessage.Text = "Please fill all the  fields";
            return false;

        }
        else if ((!Int32.TryParse(phone, out homephone)) || ((mobile.Length != 0) && (!Int32.TryParse(mobile, out mobilephone))))
        {
            lblMessage.Text = "Your number is invalid, please type integer";
            return false;
        }
        else if (atplace == -1)
        {
            lblMessage.Text = "Your email must contain @";
            return false;

        }
        else { return true; }


    }


}