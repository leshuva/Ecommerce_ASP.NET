﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using BusinessLayer;


public partial class Login : PageHelper
{
    protected void Page_Load(object sender, EventArgs e)
    {
        lgn.Authenticate += new AuthenticateEventHandler(lgnUserLogin_Authenticate);
        lgn.RememberMeSet= false;
        lgn.DisplayRememberMe = false;
        lgn.FailureText = "";
    }

    protected void lgnUserLogin_Authenticate(object sender, AuthenticateEventArgs e)
    {

        

        HatHelpers.User currentUser = BusinessLayer.CheckAccess(lgn.UserName.Trim(), lgn.Password);
        (Roles.Provider as HatShopRoleProvider).RoleUser = currentUser;
        Session[PageHelper.CURRENT_USER] = currentUser;

        System.Web.UI.MasterPage master = this.Master;
        (master.FindControl("lblAdmin") as Label).Visible = false;
        (master.FindControl("btnLogout") as Button).Visible = false;
        master.FindControl("ddlAdminShow").Visible = false;



        if (currentUser.IsAuthorised)
        {
            lgn.FailureText = "";

            string firstName = currentUser.FirstName;
            string lastName = currentUser.LastName;
            lblGreeting.Text = "<br/>Welcome " + currentUser.FirstName + "!" + "<br/>";

            (master.FindControl("lblUsername") as Label).Text = firstName + " " + lastName;
            (master.FindControl("btnLogout") as Button).Visible = true;

            switch (currentUser.UserAccessType)
            {
                case HatHelpers.UserAccess.Admin:
                    (master.FindControl("lblAdmin") as Label).Visible = true;
                    master.FindControl("ddlAdminShow").Visible = true;
                    e.Authenticated = true;
                    
                    break;
                case HatHelpers.UserAccess.Customer:

                    Response.Redirect("~/Cart.aspx");
                    
                    e.Authenticated = true;
                    break;
                default:
                    break;

            }

            return;
        }
  

        else
        {

            Session.Abandon();
            if (currentUser != null && currentUser.AccountEnabled == "No")
            {
                lblGreeting.Text = "<br/> Your account has been disabled <br/>";
            }
            else
            {
                lblGreeting.Text = "<br/> Incorrect login/password <br/>";
            }
            return;

        }



    }

}