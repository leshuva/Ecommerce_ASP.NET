﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;
using BusinessLayer;
using System.Web.Security;
using System.Net.Mail;


public partial class Registration : PageHelper
{

    protected void Page_Load(object sender, EventArgs e)
    {

        btnRegister.Click += new EventHandler(btnRegister_Click);
        

        if (this.IsPostBack)
        {
            lblGreeting.Text = "";
        }

    }

    protected void btnRegister_Click(object sender, EventArgs e)
    {
        int Phone, Mobile;
        string Email = txtEMail.Text;
        int atPlace = Email.IndexOf('@');
        //validation
        if (txtFirstName.Text.Length == 0 || txtLastName.Text.Length == 0)
        {
            lblGreeting.Text = "<br/> Input your name please <br/>";
        }
        else if (txtAddress.Text.Length == 0)
        {
            lblGreeting.Text = "<br/> Input your address please <br/>";

        }
        else if (txtLogin.Text.Length == 0 || txtPassword.Text.Length == 0)
        {
            lblGreeting.Text = "<br/> Input your login/password please <br/>";

        }
        else if (!Int32.TryParse(txtPhone.Text, out Phone) || ((txtMobile.Text.Length != 0) && (!Int32.TryParse(txtMobile.Text, out Mobile))))
        {
            lblGreeting.Text = "<br/> Phonenumber should be integer, input number <br/>";
        }
        else if (txtPhone.Text.Length == 0)
        {


            lblGreeting.Text = "<br/> Input your phonenumber please <br/>";
        }
        else if (txtEMail.Text.Length == 0)
        {
            lblGreeting.Text = "<br/> Input your Email please <br/>";

        }
        else if (atPlace == -1)
        {
            lblGreeting.Text = "<br/> Your Email is incorrect, it should contain @ <br/>";
        }
        else
        {
            BusinessLayer.SaveRegistration(txtFirstName.Text, txtLastName.Text, txtPhone.Text, txtMobile.Text, txtEMail.Text, txtAddress.Text, txtLogin.Text, txtPassword.Text);
            lblGreeting.Text = "<br/>Welcome " + txtFirstName.Text + "!" + "<br/>";
            Session["FirstName"] = txtFirstName.Text;
            Session["LastName"] = txtLastName.Text;

            SendingEmail();
        }

    }


  
    //sending email to customer


    private void SendingEmail()
    {

        MailAddress toAddress = new MailAddress(txtEMail.Text);
        MailAddress fromAddress = new MailAddress("QualityHats@qualityhats.com");
        MailMessage message = new MailMessage(fromAddress, toAddress);
        
        message.Bcc.Add(new MailAddress("leshuvaeva@gmail.com"));

        message.Subject = "Welcome to Quality Hats!";
        message.Body = "Dear " + txtFirstName.Text + "!"+ " "+ @"Congratulations, you have just registered in the Quality Hats shop!
        Your login is: " + txtLogin.Text + ", your password is: " + txtPassword.Text + ".";
        SmtpClient mailClient = new SmtpClient();

        try
        {
            mailClient.Host = "localhost";
            mailClient.Send(message);
        }
        catch (SmtpException smtpEx)
        {
            Response.Write("Email is not sent due to system error: " + smtpEx.Message);
        }
        catch (Exception ex)
        {
            Response.Write("Error: " + ex.ToString());
        }





    }









}