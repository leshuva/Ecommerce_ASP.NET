﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using HatHelpers;

/// <summary>
/// Summary description for HatShopRoleProvider
/// Class  to separate users Roles
/// </summary>
public class HatShopRoleProvider : RoleProvider
{
    //class User is in the HatHelpers library where there is all the info about user
    public static readonly string ROLE_ADMIN = "Admin";
    public static readonly string ROLE_CUSTOMER = "Customer";

    private string[] _roles = new string[] { ROLE_ADMIN, ROLE_CUSTOMER };
    private User _user;


    public User RoleUser 
    {
        get {return _user;}
        set { _user = value; }
    }

	public HatShopRoleProvider()
	{
        
	}



    public override string[] GetAllRoles()
    {
        return _roles;
    }

    //check if the user has role Admin or Customer. Need for access restriction to several pages
    public override string[] GetRolesForUser(string username)
    {
        string[] roles = new string[0];
        if (_user != null )
        {
            switch(_user.UserAccessType)
            {
                case UserAccess.Admin:
                    roles = _roles;
                    break;
                case UserAccess.Customer:
                    roles = new string[] {ROLE_CUSTOMER};
                    break;
            }
            
        }
        return roles;
    }


    public override bool IsUserInRole(string username, string roleName)
    {
        if (roleName == _roles[0] && _user.UserAccessType == UserAccess.Admin)
        {
            return true;
        }

        if (roleName == _roles[1] && (_user.UserAccessType == UserAccess.Admin || _user.UserAccessType == UserAccess.Customer))
        {
            return true;
        }
        return false;
    }

    public override void AddUsersToRoles(string[] usernames, string[] roleNames)
    {
        throw new NotImplementedException();
    }

    public override string ApplicationName
    {
        get
        {
            throw new NotImplementedException();
        }
        set
        {
            throw new NotImplementedException();
        }
    }

    public override void CreateRole(string roleName)
    {
        throw new NotImplementedException();
    }

    public override bool DeleteRole(string roleName, bool throwOnPopulatedRole)
    {
        throw new NotImplementedException();
    }

    public override string[] FindUsersInRole(string roleName, string usernameToMatch)
    {
        throw new NotImplementedException();
    }

    public override string[] GetUsersInRole(string roleName)
    {
        throw new NotImplementedException();
    }

    public override void RemoveUsersFromRoles(string[] usernames, string[] roleNames)
    {
        throw new NotImplementedException();
    }

    public override bool RoleExists(string roleName)
    {
        throw new NotImplementedException();
    }
}