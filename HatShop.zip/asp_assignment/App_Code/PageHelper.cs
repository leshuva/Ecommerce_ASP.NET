﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BusinessLayer;
using HatHelpers;
using System.Data.OleDb;

/// <summary>
/// Summary description for PageHelper
/// Almost all the pages inherit this class in order to use the same data
/// It helps to connect with Business logic and write log file
/// </summary>
public class PageHelper : System.Web.UI.Page
{

    public static readonly string CURRENT_USER = "user";
    public static readonly string SHOPPING_CART = "shopping_cart";
    public static readonly string USER_EXCEPTION = "user exception";
    public static readonly string PAR_QUESTION = "q";


    #region Fields
    private HatBusiness _hatBusiness;
    private Logger _logger = Logger.Instance;

    #endregion

    #region Properties

    protected HatBusiness BusinessLayer
    {
        get { return _hatBusiness; }
    }

    protected Logger CurrentLogger
    {
        get { return _logger; }
    }

    #endregion

    public PageHelper()
	{

        string logPath = System.Configuration.ConfigurationManager.ConnectionStrings["HatShopLog"].ConnectionString;
        _logger.LogFileName = HttpContext.Current.Server.MapPath(logPath); //("~/Log/HatShop.log");
        //TODO: Change to Web.Config
        //OleDbConnectionStringBuilder sb = new OleDbConnectionStringBuilder();
        //sb.Provider = "Microsoft.ACE.OLEDB.12.0";
        //sb.DataSource = HttpContext.Current.Server.MapPath("~/uploads/HatShop.accdb");

        //string connectionString = sb.ConnectionString;
        string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["HatShopDataBase"].ConnectionString;

        _hatBusiness = new HatBusiness(connectionString, _logger);

	}

    
}