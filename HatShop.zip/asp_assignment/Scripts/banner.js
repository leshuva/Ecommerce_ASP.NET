﻿var refreshIntervalId;
var image_tray = new Array();  //an array to hold the uploaded images

image_tray[0] = "Hatimg/banner1.jpg";
image_tray[1] = "Hatimg/banner2.jpg";
image_tray[2] = "Hatimg/banner3.jpg";
image_tray[3] = "Hatimg/banner4.jpg";
image_tray[4] = "Hatimg/banner5.jpg";
image_tray[5] = "Hatimg/banner6.jpg";



var image_length = image_tray.length - 1;
var image_number = 0;


function change_image(num) {

    image_number = image_number + num;

    if (image_number > image_length) {
        image_number = 0;
    }
    if (image_number < 0) {
        image_number = image_length;
    }

    var bannerContainer = document.getElementById("banner_container");
    bannerContainer.innerHTML = '<img src=' + image_tray[image_number] + ' id="banner" alt="Quality hats" />';
    return false;
}

function autoSlide() {

    refreshIntervalId = setInterval("change_image(1)", 3000);
}


window.onload = autoSlide;
