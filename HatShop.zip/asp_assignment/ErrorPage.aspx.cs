﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HatHelpers;

public partial class ErrorPage : PageHelper
{
    private static readonly string MESSAGE_DEFAULT = "We have already got notification about the problem and we will do our best to fix it. Please try to perform the same operation after some time.";

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!(Session[PageHelper.USER_EXCEPTION] != null && Session[PageHelper.USER_EXCEPTION] is ErrorToken))
        {
            lblMessage.Text = MESSAGE_DEFAULT;
            return;
        }
        ErrorToken token = (Session[PageHelper.USER_EXCEPTION] as ErrorToken);



        if (User.IsInRole(HatShopRoleProvider.ROLE_ADMIN))
        {
            string message = "Message: " + token.AdminMessage + " ";
            message += "Exception: " + token.Exception.GetType().ToString();
            message += "Exception message: " + token.Exception.Message;

            if (token.Exception.InnerException != null)
            {
                message += "Inner Exception: " + token.Exception.InnerException.GetType().ToString();
                message += "Inner Exception message: " + token.Exception.InnerException.Message;
            }

            lblMessage.Text = message;
            Session[PageHelper.USER_EXCEPTION] = null;
            return;
        }
        if (User.IsInRole(HatShopRoleProvider.ROLE_CUSTOMER))
        {
            lblMessage.Text = token.Message;
            Session[PageHelper.USER_EXCEPTION] = null;
            return;
        }
    }
}