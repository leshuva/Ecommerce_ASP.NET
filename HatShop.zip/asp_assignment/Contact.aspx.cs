﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net.Mail;

public partial class Contact : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        btnSubmitQuestion.Click += new EventHandler(btnSubmitQuestion_Click);
        lblMessage.Text = "<h4>If you have questions please call 0086-10-123456 or use the message board below to contact us!</h4>";
    }


    private void btnSubmitQuestion_Click(object sender, EventArgs e)
    {
        int atEmail = txtEmail.Text.IndexOf('@');
        //validation
        if ((txtName.Text.Length == 0) || (txtLastName.Text.Length == 0) || (txtEmail.Text.Length == 0) || (txtQuestion.Text.Length == 0) || (txtSubject.Text.Length == 0))
        {

            lblMessage.Text = "Please fill all the fields in the form";
            return;
        }
        else if (atEmail == -1)
        {
            lblMessage.Text = "Your email is incorrect, it should contain @";
            return;

        }
        else
        {

            lblMessage.Text = "Thank you for your message! We will be in contact with you soon.";
            SendingEmail();

        }



    }

    //email is to be sent to admin with customer details
    private void SendingEmail()
    {

        MailAddress toAddress = new MailAddress("leshuvaeva@gmail.com");
        MailAddress fromAddress = new MailAddress("QualityHats@qualityhats.com");
        MailMessage message = new MailMessage(fromAddress, toAddress);
        message.Subject = txtSubject.Text;
        message.Body = "Email from: " + txtEmail.Text +"<br/> "+ txtName.Text + " " + txtLastName.Text + " <br/>" + txtQuestion.Text;

        SmtpClient mailClient = new SmtpClient();

        try
        {
            mailClient.Host = "localhost";
            mailClient.Send(message);
        }
        catch (SmtpException smtpEx)
        {
            Response.Write("Email is not sent due to system error: " + smtpEx.Message);
        }
        catch (Exception ex)
        {
            Response.Write("Error: " + ex.ToString());
        }





    }
}