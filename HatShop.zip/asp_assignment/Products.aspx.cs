﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;
using System.IO;
using BusinessLayer;
using HatHelpers;


public partial class Products : PageHelper
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }


    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            LoadCategory();

            string question = Request.QueryString[PageHelper.PAR_QUESTION];
            if (question == null || question == string.Empty)
            {
                LoadProductByCategory();
            }
            else
            {
                LoadProductBySearch(question);
            }
            
        }


    }

    //add to cart button
    public void btnAddProduct_Click(object sender, EventArgs e)
    {

        Button addProductButton = (sender as Button);

        DataListItem item = addProductButton.Parent as DataListItem;

        var colorControl = (item.FindControl("ddlprColor") as DropDownList);
        string colorID = colorControl.SelectedItem.Value;
        string colorName = colorControl.SelectedItem.Text;

        var categoryControl = (item.FindControl("lblGrvCategoryName") as Label);

        string category = categoryControl.Text;
        var productIDControl = (item.FindControl("lblGrvProductId") as Label);
        string productID = productIDControl.Text;

        var productNameControl = (item.FindControl("lblGrvProductName") as Label);
        string productName = productNameControl.Text;

        var unitPriceControl = (item.FindControl("lblGrvUnitPrice") as Label);
        string unitPrice = unitPriceControl.Text;

        int quantity = 1;

        if (Session[SHOPPING_CART] == null)
        {
            Session[SHOPPING_CART] = new ShoppingCart();
        }

        ShoppingCart cart = Session[SHOPPING_CART] as ShoppingCart;

        cart.AddProduct(productID, productName, category, colorID, colorName, unitPrice, quantity.ToString());

    }

    //show product details from business logic
    public void LoadAllProductDetails()
    {
        ErrorToken token;
        DataTable dtProducts = BusinessLayer.LoadAllProductDetails(out token);

        if (token != null)
        {
            Session[USER_EXCEPTION] = token;
            Response.Redirect("~/ErrorPage.aspx");
        }

        dlstProductList.DataSource = dtProducts;
        dlstProductList.DataBind();


    }

    protected void btnViewAllProducts_Click(object sender, EventArgs e)
    {
        LoadAllProductDetails();

    }
    //sort by category
    public void LoadProductByCategory()
    {
        string categoryIdStr = ddlViewCategories.SelectedValue.ToString();
        DataTable dtProductByCategory;

        ErrorToken token;


        int categoryId;
        if (Int32.TryParse(categoryIdStr, out categoryId) && categoryId == -1)
        {

            dtProductByCategory = BusinessLayer.LoadAllProductDetails(out token);
        }
        else
        {
            dtProductByCategory = BusinessLayer.GetProductsByCategory(categoryIdStr, out token);
        }

        if (token != null)
        {
            Session[USER_EXCEPTION] = token;
            Response.Redirect("~/ErrorPage.aspx");
        }

        dlstProductList.DataSource = dtProductByCategory;
        dlstProductList.DataBind();

    }
    //search product by name
    public void LoadProductBySearch(string searchString)
    {
        

        ErrorToken token;


        DataTable dtFoundProducts = BusinessLayer.SearchProducts(searchString, out token);

        if (token != null)
        {
            Session[USER_EXCEPTION] = token;
            Response.Redirect("~/ErrorPage.aspx");
        }

        dlstProductList.DataSource = dtFoundProducts;
        dlstProductList.DataBind();

    }

    //view products by category
    public void ddlViewProductByCategory_SelectedIndexChanged(object sender, EventArgs e)
    {

        LoadProductByCategory();
    }
    
    public void LoadCategory()
    {

        DataTable dtCategory = BusinessLayer.LoadCategories();

        DataRow row = dtCategory.NewRow();
        row["CategoryID"] = -1;
        row["CategoryName"] = "All";
        row["Description"] = "All Categories";

        dtCategory.Rows.InsertAt(row, 0);
        ddlViewCategories.DataSource = dtCategory;
        ddlViewCategories.DataBind();

    }
    //choose color
    protected void ddlColor_databound(object sender, DataListItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            var myDropDownList = e.Item.FindControl("ddlprColor") as DropDownList;
            int currentItemID = int.Parse(this.dlstProductList.DataKeys[e.Item.ItemIndex].ToString());

            myDropDownList.DataSource = BusinessLayer.LoadColor();
            myDropDownList.DataBind();
        }
    }


}