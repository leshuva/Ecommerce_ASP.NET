﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using BusinessLayer;




public partial class Account : PageHelper
{
    protected void Page_Load(object sender, EventArgs e)
    {


        if (!this.IsPostBack)
        {

            SetData();
            GrVCustomerOrders.PageIndexChanging += new GridViewPageEventHandler(GrVCustomerOrders_PageIndexChanging);

        }

    }


    private void SetData()
    {
        if (Session[PageHelper.CURRENT_USER] != null && Session[PageHelper.CURRENT_USER] is HatHelpers.User)
      
        {
            HatHelpers.User currentUser = Session[PageHelper.CURRENT_USER] as HatHelpers.User;

            string customerId = currentUser.UserID; //"";
          


            DataTable dtShopAccount = BusinessLayer.GetCustomerOrderByCustomerID(customerId);
            GrVCustomerOrders.DataSource = dtShopAccount;
            GrVCustomerOrders.DataBind();

            GrVCustomerOrders.AllowPaging = true;
            GrVCustomerOrders.PageSize = 5;
        }

    }

    //show data
    protected void GrVCustomerOrders_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.DataItem == null)
        {
            return;
        }
        string orderID = (e.Row.DataItem as DataRowView).Row["OrderID"].ToString();

        GridView GrVOrderDetail = e.Row.FindControl("GrVOrderDetail") as GridView;

        DataTable dtShopAccount = BusinessLayer.LoadOrderDetails(orderID);

        GrVOrderDetail.DataSource = dtShopAccount;
        GrVOrderDetail.DataBind();
    }

    //grandtotal price counting
    protected string totalprice()
    {

        HatHelpers.ShoppingCart cart = Session[PageHelper.SHOPPING_CART] as HatHelpers.ShoppingCart;
        string grandTotal = (cart.Total + (cart.Total * 0.15)).ToString();
        return grandTotal;
    }

    //paging
    private void GrVCustomerOrders_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        lblMessage.Text = "";
        GrVCustomerOrders.PageIndex = e.NewPageIndex;
        SetData();
    }

}