﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using BusinessLayer;

public partial class SecuredCustomer_CustomerProfile : PageHelper
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        { 
            SetData(); 
        }
       
    }

    //take all the details from Session[current_user]

    private void SetData()
    {
        if (Session[PageHelper.CURRENT_USER] != null && Session[PageHelper.CURRENT_USER] is HatHelpers.User)
        {
            HatHelpers.User user = Session[PageHelper.CURRENT_USER] as HatHelpers.User;
            lblFirstName.Text = user.FirstName;
            lblLastName.Text = user.LastName;
            lblEmail.Text = user.Email;
            lblAddress.Text = user.Address;
            lblPhone.Text = user.HomePhone;
            lblMobile.Text = user.MobilePhone;
            lblLogin.Text = user.Login;
        }
    }
}