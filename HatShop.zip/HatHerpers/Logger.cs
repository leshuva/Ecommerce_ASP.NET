﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace HatHelpers
{
    /// <summary>
    /// the class for logging
    /// </summary>
    public class Logger
    {

        
        private static Logger _instance;

        public static Logger Instance
        {
            get 
            {
                if (_instance == null)
                {
                    _instance = new Logger();
                }
                return _instance;
            }
        }

        private string _logFileName;

        public string LogFileName
        {
            get { return _logFileName; }
            set { _logFileName = value; }
        }

        private Logger()
        {
        }


        public void WriteLog(string message)
        {
            if (_logFileName == null)
            {
                return;
            }

            try
            {
                File.AppendAllLines(_logFileName, new string[] { DateTime.Now.ToString() + " " + message});
            }
            catch 
            { 
            }
        }

    }
}
