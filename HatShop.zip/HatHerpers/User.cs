﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HatHelpers
{

    public enum UserAccess { Admin, Customer}
    public class User
    {
        #region Properties

        public int UserId
        {
            get;
            set;
        }

        public UserAccess UserAccessType
        {
            get;
            set;
        }

        public bool IsAuthorised
        {
            get;
            set;
        }

        public string FirstName
        {
            get;
            set;
        }

        public string LastName
        {
            get;
            set;
        }

        public string Login
        {
            get;
            set;

        }

        public string Email
        {
            get;
            set;
        }

        public string AccountEnabled
        {
            get;
            set;
        }

        public string UserID
        {

            get;
            set;
        }

        public string Address
        {
            get;
            set;

        }

        public string HomePhone
        {
            get;
            set;

        }

        public string MobilePhone
        {
            get;
            set;

        }

        #endregion

    }
}
