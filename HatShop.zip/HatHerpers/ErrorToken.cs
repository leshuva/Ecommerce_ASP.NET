﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HatHelpers
{
    public class ErrorToken
    {
        //the class to describe exceptions
        public string Message { get; set; }

        public Exception Exception { get; private set; }

        public string AdminMessage { get; private set; }

        public ErrorToken(string message, Exception ex, string adminMessage)
        {
            this.Message = message;
            this.Exception = ex;
            this.AdminMessage = adminMessage;

        }

    }
}
