﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataLayer;
using System.Data.OleDb;
using System.Data;
using System.Web;
using System.IO;
using HatHelpers;


namespace BusinessLayer
{
    /// <summary>
    /// All the Business logic in this class
    /// </summary>
    public class HatBusiness
    {
        
        #region Fields
        private HatData _hatData;
        private Logger _logger;

        private static readonly string ROLE_ADMIN = "admin";

        #endregion

        #region Constructor
        public HatBusiness(string connectionString, Logger logger)
        {
            _logger = logger;
            _hatData = new HatData(connectionString, logger);

        }

        #endregion

        #region Business logic
        /// <summary>
        /// save product
        /// </summary>
        /// <param name="ProductName"></param>
        /// <param name="Description"></param>
        /// <param name="UnitPrice"></param>
        /// <param name="CategoryId"></param>
        /// <param name="SupplierId"></param>
        /// <param name="Filename"></param>
        /// <param name="token"></param>
        public void SaveProducts(string ProductName, string Description, string UnitPrice, string CategoryId, string SupplierId, string Filename, out ErrorToken token)
        {

            StringBuilder queryStringBuilder = new StringBuilder(
                @"Insert into Product([ProductName],[Description],[UnitPrice],[CategoryId],[SupplierId],[Picture])
                VALUES(?,?,?,?,?,?)
");
            List<OleDbParameter> parameters = new List<OleDbParameter>();
            parameters.Add(new OleDbParameter("ProductName", ProductName));
            parameters.Add(new OleDbParameter("Description", Description));
            parameters.Add(new OleDbParameter("UnitPrice", UnitPrice));
            parameters.Add(new OleDbParameter("CategoryId", CategoryId));
            parameters.Add(new OleDbParameter("SupplierId", SupplierId));
            parameters.Add(new OleDbParameter("Filename", Filename));


            string queryString = queryStringBuilder.ToString();
            _hatData.UpdateData(queryString, parameters, out token);
        }
        /// <summary>
        /// get colorId knowing name
        /// </summary>
        /// <param name="colorName"></param>
        /// <param name="token"></param>
        /// <returns></returns>
        private string GetColorIdByName(string colorName, out ErrorToken token)
        {
            
            string query = "SELECT ColorID FROM ProductColor WHERE ColorName = ?";
            List<OleDbParameter> parameters = new List<OleDbParameter>();
            parameters.Add(new OleDbParameter("colorName", colorName));

            string colorId = _hatData.GetSingleValue(query, parameters, out token).ToString();
            return colorId;
        }

        private string GetCategoryIdByName(string categoryName, out ErrorToken token)
        {
            //string query = "Select CategoryID from Category Where CategoryName= '" + categoryName + "'";
            string query = "Select CategoryID from Category Where CategoryName= ?";

            List<OleDbParameter> parameters = new List<OleDbParameter>();

            parameters.Add(new OleDbParameter("CategoryName", categoryName));

            string categoryId = _hatData.GetSingleValue(query, parameters, out token).ToString();
            return categoryId;
        }
        private string GetSupplierIdByName(string supplierName, out ErrorToken token)
        {
            string query = "Select SupplierID from Supplier Where SupplierName= ?";

            List<OleDbParameter> parameters = new List<OleDbParameter>();
            parameters.Add(new OleDbParameter("SupplierName", supplierName));

            string supplierId = _hatData.GetSingleValue(query, parameters, out token).ToString();
            return supplierId;
        }
        /// <summary>
        /// updating product
        /// </summary>
        /// <param name="productId"></param>
        /// <param name="productName"></param>
        /// <param name="description"></param>
        /// <param name="unitPrice"></param>
        /// <param name="categoryName"></param>
        /// <param name="supplierName"></param>
        /// <param name="filename"></param>
        /// <param name="token"></param>
        public void UpdateProduct(string productId
            , string productName
            , string description
            , string unitPrice
            , string categoryName
            , string supplierName
            , string filename
            , out ErrorToken token
            )
        {

            string categoryId = GetCategoryIdByName(categoryName, out token);

            if (token != null)
            {
                return;
            }

            string supplierID = GetSupplierIdByName(supplierName, out token);
            if (token != null)
            {
                return;
            }


            StringBuilder queryStringBuilder = new StringBuilder("UPDATE Product SET ProductName = ");
            queryStringBuilder.Append("'" + productName + "'");
            queryStringBuilder.Append(", Description = '" + description + "'");
            queryStringBuilder.Append(", UnitPrice = '" + unitPrice + "'");

            queryStringBuilder.Append(", CategoryID = '" + categoryId + "'");
            queryStringBuilder.Append(", SupplierID = '" + supplierID + "'");
            queryStringBuilder.Append(", Picture = '" + filename + "'");
            queryStringBuilder.Append(" WHERE ProductID = ");
            queryStringBuilder.Append(productId);

            string queryString = queryStringBuilder.ToString();
            _hatData.UpdateData(queryString);


        }

        /// <summary>
        /// deleting product (hiding from the interface not deleting in the db)
        /// </summary>
        /// <param name="productId"></param>
        /// <param name="token"></param>
        public void DeleteProduct(string productId, out ErrorToken token)
        {

            string query = "UPDATE PRODUCT SET [Status] = 'Deleted' WHERE PRODUCT.ProductID = ?";
            List<OleDbParameter> parameters = new List<OleDbParameter>();
            OleDbParameter parProductId = new OleDbParameter("ProductId", productId);

            parameters.Add(parProductId);

            _hatData.UpdateData(query, parameters, out token);

        }
        /// <summary>
        /// update customer
        /// </summary>
        /// <param name="customerId"></param>
        /// <param name="firstName"></param>
        /// <param name="lastName"></param>
        /// <param name="homePhone"></param>
        /// <param name="mobile"></param>
        /// <param name="email"></param>
        /// <param name="address"></param>
        /// <param name="login"></param>
        /// <param name="password"></param>
        /// <param name="accessType"></param>
        /// <param name="accountEnable"></param>
        public void UpdateCustomer(
        string customerId,
        string firstName,
        string lastName,
        string homePhone,
        string mobile,
        string email,
        string address,
        string login,
        string password,
        string accessType,
        string accountEnable)
        {
            StringBuilder queryStringBuilder = new StringBuilder("Update Customer SET FirstName = ");
            queryStringBuilder.Append("'" + firstName + "'");
            queryStringBuilder.Append(", LastName = " + "'" + lastName + "'");
            queryStringBuilder.Append(", HomePhone = " + "'" + homePhone + "'");
            queryStringBuilder.Append(", MobilePhone = " + "'" + mobile + "'");
            queryStringBuilder.Append(", [E-Mail] = " + "'" + email + "'");
            queryStringBuilder.Append(", Address = " + "'" + address + "'");
            queryStringBuilder.Append(", Login = " + "'" + login + "'");
            queryStringBuilder.Append(", [Password] = " + "'" + password + "'");
            queryStringBuilder.Append(", AccessType = " + "'" + accessType + "'");
            queryStringBuilder.Append(", AccountEnabled =" + "'" + accountEnable + "'");
            queryStringBuilder.Append(" Where CustomerID = ");
            queryStringBuilder.Append(customerId);

            string sqlQuery = queryStringBuilder.ToString();
            _hatData.UpdateData(sqlQuery);


        }

        public void AddCustomer(string firstName, string lastName, string homePhone, string mobile, string email, string address, string login, string password)
        {

            StringBuilder sb = new StringBuilder("Insert into Customer (FirstName, LastName, HomePhone, MobilePhone, [E-Mail], Address, Login , [Password]) Values (");
            sb.Append("'" + firstName + "'");
            sb.Append(",");
            sb.Append("'" + lastName + "'");
            sb.Append(",");
            sb.Append("'" + homePhone + "'");
            sb.Append(",");
            sb.Append("'" + mobile + "'");
            sb.Append(",");
            sb.Append("'" + email + "'");
            sb.Append(",");
            sb.Append("'" + address + "'");
            sb.Append(",");
            sb.Append("'" + login + "'");
            sb.Append(",");
            sb.Append("'" + password + "'");
            sb.Append(")");

            string query = sb.ToString();
            _hatData.UpdateData(query);

        }

        public void UpdateSupplier(string supplierID, string supplierName, string workPhone, string mobile, string email)
        {

            StringBuilder sb = new StringBuilder("UPDATE SUPPLIER SET SupplierName = ");
            sb.Append("'" + supplierName + "'");
            sb.Append(", WorkPhone = " + "'" + workPhone + "'");
            sb.Append(", MobilePhone = " + "'" + mobile + "'");
            sb.Append(", [E-mail] = " + "'" + email + "'");
            sb.Append(" Where SupplierID = ");
            sb.Append(supplierID);

            string querystring = sb.ToString();
            _hatData.UpdateData(querystring);



        }


        public void AddSupplier(string supplierName, string workPhone, string mobile, string email)
        {
            StringBuilder sb = new StringBuilder("INSERT INTO Supplier ( SupplierName, WorkPhone, MobilePhone, [E-mail] ) VALUES(");
            sb.Append("'" + supplierName + "'");
            sb.Append(",");
            sb.Append("'" + workPhone + "'");
            sb.Append(",");
            sb.Append("'" + mobile + "'");
            sb.Append(",");
            sb.Append("'" + email + "'");
            sb.Append(")");

            string query = sb.ToString();
            _hatData.UpdateData(query);
        }

        /// <summary>
        /// Save Category
        /// </summary>
        /// <param name="CategoryName"></param>
        /// <param name="CategoryDescription"></param>
        public void SaveCategory(string CategoryName, string CategoryDescription)
        {

            System.Text.StringBuilder queryStringBuilder = new System.Text.StringBuilder("Insert into Category([CategoryName],[Description])");
            queryStringBuilder.Append("values('");
            queryStringBuilder.Append(CategoryName);
            queryStringBuilder.Append("','");
            queryStringBuilder.Append(CategoryDescription);

            queryStringBuilder.Append("'");
            queryStringBuilder.Append(")");
            string queryString = queryStringBuilder.ToString();
            _hatData.UpdateData(queryString);

        }
        /// <summary>
        /// update Category
        /// </summary>
        /// <param name="categoryId"></param>
        /// <param name="categoryName"></param>
        /// <param name="description"></param>
        public void UpdateCategory(string categoryId, string categoryName, string description)
        {
            StringBuilder queryStringBuilder = new StringBuilder("Update [CATEGORY] SET CategoryName = ");
            queryStringBuilder.Append("'" + categoryName + "'");
            queryStringBuilder.Append(", Description = " + "'" + description + "'");
            
            queryStringBuilder.Append(" Where CategoryID = ");
            queryStringBuilder.Append(categoryId);

            string sqlQuery = queryStringBuilder.ToString();
            _hatData.UpdateData(sqlQuery);


        
        
        }

        /// <summary>
        /// Save Supplier
        /// </summary>
        /// <param name="SupplierName"></param>
        /// <param name="WorkPhone"></param>
        /// <param name="Mobile"></param>
        /// <param name="Email"></param>
        public void SaveSupplier(string SupplierName, string WorkPhone, string Mobile, string Email)
        {

            System.Text.StringBuilder queryStringBuilder = new System.Text.StringBuilder("Insert into Supplier([SupplierName],[WorkPhone],[MobilePhone],[E-Mail])");
            queryStringBuilder.Append("values('");
            queryStringBuilder.Append(SupplierName);
            queryStringBuilder.Append("','");
            queryStringBuilder.Append(WorkPhone);
            queryStringBuilder.Append("','");
            queryStringBuilder.Append(Mobile);
            queryStringBuilder.Append("','");
            queryStringBuilder.Append(Email);
            queryStringBuilder.Append("'");
            queryStringBuilder.Append(")");
            string queryString = queryStringBuilder.ToString();
            _hatData.UpdateData(queryString);

        }

        /// <summary>
        /// Save ProductColor
        /// </summary>
        /// <param name="ColorName"></param>
        public void SaveProductColor(string ColorName)
        {

            System.Text.StringBuilder queryStringBuilder = new System.Text.StringBuilder("Insert into ProductColor([ColorName]");
            queryStringBuilder.Append("values('");
            queryStringBuilder.Append(ColorName);

            queryStringBuilder.Append("'");
            queryStringBuilder.Append(")");
            string queryString = queryStringBuilder.ToString();
            _hatData.UpdateData(queryString);

        }

        public int GetNewProductId()
        {

            object productIdRaw = _hatData.GetSingleValue("Select @@IDENTITY");

            int result;

            if (Int32.TryParse(productIdRaw.ToString(), out result))
            {
                return result;
            }
            else
            {
                _logger.WriteLog("HatBusiness.GetNewProductId: could not convert productId from database to integer: " + productIdRaw.ToString());

                result = -1;
            }

            return result;
        }
        /// <summary>
        /// Load active products (all details)
        /// </summary>
        /// <returns></returns>
        public DataTable LoadProducts()
        {
            DataTable result = _hatData.GetData("SELECT * From Product WHERE Product.[Status] = 'Active'");

            return result;
        }


        public DataTable LoadSuppliers()
        {
            DataTable result = _hatData.GetData("SELECT * FROM Supplier");
            return result;
        }

        public DataTable LoadCategories()
        {
            DataTable result = _hatData.GetData("SELECT * From Category");
            return result;
        }

        /// <summary>
        /// choose the product in the category
        /// </summary>
        /// <param name="categoryID"></param>
        /// <param name="token"></param>
        /// <returns></returns>
        public DataTable GetProductsByCategory(string categoryID, out ErrorToken token)
        {

            string query = @"SELECT PRODUCT.ProductID
, PRODUCT.ProductName as [ProductName] 
, PRODUCT.Description as [Description]
, PRODUCT.UnitPrice as [UnitPrice] 
, PRODUCT.CategoryID as [CategoryID]
, PRODUCT.SupplierID as [SupplierID]
, PRODUCT.Picture as [Picture]
, PRODUCT.Status as [Status]
,  Category.CategoryName
FROM PRODUCT, Category,Supplier Where Product.[Status] = 'Active' AND Product.SupplierId=Supplier.SupplierID AND Category.CategoryID=Product.CategoryId  AND PRODUCT.CATEGORYId = ?;";

            List<OleDbParameter> parameters = new List<OleDbParameter>();

            parameters.Add(new OleDbParameter("CategoryID", categoryID));

            DataTable result = _hatData.GetData(query, parameters, out token);
            return result;

        }

        //Search by part of product name
        public DataTable SearchProducts(string searchString, out ErrorToken token)
        {
            string query = @"SELECT PRODUCT.ProductID
, PRODUCT.ProductName as [ProductName] 
, PRODUCT.Description as [Description]
, PRODUCT.UnitPrice as [UnitPrice] 
, PRODUCT.CategoryID as [CategoryID]
, PRODUCT.SupplierID as [SupplierID]
, PRODUCT.Picture as [Picture]
, PRODUCT.Status as [Status]
,  Category.CategoryName
FROM PRODUCT, Category,Supplier Where Product.[Status] = 'Active' AND Product.SupplierId=Supplier.SupplierID AND Category.CategoryID=Product.CategoryId;";

            List<OleDbParameter> parameters = new List<OleDbParameter>();
            DataTable result = _hatData.GetData(query, parameters, out token);

            var foundRows = result.Select("ProductName LIKE '%" + searchString + "%'");
            DataTable searchResult = result.Clone();

            foreach (DataRow foundRow in foundRows)
            {
                DataRow newRow = searchResult.NewRow();
                newRow.ItemArray = foundRow.ItemArray;
                searchResult.Rows.Add(newRow);
            }

            return searchResult;
        }

        /// <summary>
        /// Load Color
        /// </summary>
        /// <returns></returns>
        public DataTable LoadColor()
        {
            DataTable result = _hatData.GetData("SELECT * FROM ProductColor");
            return result;
        }
        /// <summary>
        /// Load Product Details, Join Tables Product Color ,Supplier, Category
        /// </summary>
        /// <returns></returns>

        public DataTable LoadAllProductDetails(out ErrorToken token)
        {

            
            DataTable result = _hatData.GetData(
                @"SELECT PRODUCT.ProductID, PRODUCT.ProductName, PRODUCT.Description, PRODUCT.UnitPrice, CATEGORY.CategoryName, SUPPLIER.SupplierName, PRODUCT.Picture 
                FROM SUPPLIER , Product, Category 
                Where Product.[Status] = 'Active' AND Product.CategoryID = Category.CategoryID AND SUpplier.SupplierID = Product.SupplierID"
                , null
                , out token 
                );

            if (token != null)
            {
                token.Message = "Unfortuntely we could not get you list of our wonderful products. We are looking for the source of the issue. Please try again later.";
            }

            return result;

        }

        /// <summary>
        /// Load Customer
        /// </summary>
        /// <returns></returns>
        public DataTable LoadCustomers()
        {

            DataTable result = _hatData.GetData("SELECT * From Customer");
            return result;
        }

        /// <summary>
        /// Load Status Select all from OrderStatus
        /// </summary>
        /// <returns></returns>
        public DataTable LoadStatus()
        {
            DataTable result = _hatData.GetData("SELECT * FROM OrderStatus");
            return result;
        }

        /// <summary>
        ///  Join Order, OrderDetails, Product, ProductColor, 
        /// </summary>
        /// <returns></returns>
        public DataTable LoadOrders()
        {
            
            string query = "SELECT ORDER.OrderID, ORDER.CustomerID, ORDER.OrderDate, ORDERSTATUS.OrderStatus, SUM ((OrderLine.Quantity)*(OrderLine.UnitPrice) +0.15*(OrderLine.Quantity)*(OrderLine.UnitPrice)) as GrandTotal FROM ORDERSTATUS INNER JOIN ([ORDER] INNER JOIN OrderLine ON ORDER.OrderID = OrderLine.OrderID) ON ORDERSTATUS.StatusID = ORDER.StatusID Group by ORDER.OrderID, ORDER.CustomerID, ORDER.OrderDate, ORDERSTATUS.OrderStatus";

            DataTable result = _hatData.GetData(query);
            return result;
        }

        public DataTable LoadOrderDetails(string OrderId)
        {

            string sqlQuery = @"SELECT p.ProductID, p.ProductName, pc.ColorName as [ProductColor], o.Quantity , o.UnitPrice, o.Quantity * o.UnitPrice as [SubTotal] 
FROM OrderLine o, PRODUCT p, ProductColor pc
WHERE o.ProductID = p.productID
AND o.ColorID = pc.ColorID
AND o.OrderID = " + OrderId;

            DataTable result = _hatData.GetData(sqlQuery);

            return result;
        }

        /// <summary>
        /// Check Login/Password for existing customer
        /// </summary>
        /// <param name="Login"></param>
        /// <param name="Password"></param>
        /// <returns></returns>
        public User CheckAccess(string Login, string Password)
        {

            
            string sqlcommand = "SELECT CustomerID, FirstName, LastName, [E-mail], [Address], [HomePhone], [MobilePhone], [AccessType], [Login], [AccountEnabled] FROM CUSTOMER WHERE Login= ? AND Password= ? ";

            OleDbParameter parLogin = new OleDbParameter("Login",Login);
            OleDbParameter parPassword = new OleDbParameter("Password",Password);

            List<OleDbParameter> parameters = new List<OleDbParameter>();
            parameters.Add(parLogin);
            parameters.Add(parPassword);

            ErrorToken token;
            DataTable result = _hatData.GetData(sqlcommand, parameters, out token);

            if (result != null && result.Rows.Count == 1)
            {
                User currentUser = new User();
                DataRow customerRow = result.Rows[0];

                currentUser.IsAuthorised = true;
                currentUser.FirstName = customerRow["FirstName"].ToString();
                currentUser.LastName = customerRow["LastName"].ToString();
                currentUser.Email = customerRow["E-mail"].ToString();
                currentUser.Address = customerRow["Address"].ToString();
                currentUser.HomePhone = customerRow["HomePhone"].ToString();
                currentUser.MobilePhone = customerRow["MobilePhone"].ToString();
                currentUser.AccountEnabled = customerRow["AccountEnabled"].ToString();
                currentUser.Login = customerRow["Login"].ToString();
                int customerId;
                if (currentUser.AccountEnabled == "No")
                {
                    currentUser.IsAuthorised = false;

                    return new User() { IsAuthorised = false, AccountEnabled = "No"};
                }
                else
                {

                    currentUser.UserID = customerRow["CustomerID"].ToString();
                    if (Int32.TryParse(customerRow["CustomerID"].ToString(), out customerId))
                    {
                        currentUser.UserId = customerId;
                    }

                    if (customerRow["AccessType"].ToString().ToLower() == ROLE_ADMIN)
                    {

                        currentUser.UserAccessType = UserAccess.Admin;

                    }
                    else
                    {
                        currentUser.UserAccessType = UserAccess.Customer;

                    }

                    return currentUser;
                }
            }

            return new User() { IsAuthorised = false };
        }

        public string messageForDisabledAccount()
        {

            return "Your accaound has been disabled";
        }

        /// <summary>
        /// Save Registration for new customers
        /// </summary>
        public void SaveRegistration(string Fname, string Lname, string HomePhone, string Mobile, string Email, string Address, string Login, string Password)
        {

            System.Text.StringBuilder queryStringBuilder = new System.Text.StringBuilder("Insert into Customer([FirstName],[LastName],[HomePhone],[MobilePhone],[E-Mail],[Address],[Login],[Password])");
            queryStringBuilder.Append("values('");
            queryStringBuilder.Append(Fname);
            queryStringBuilder.Append("','");
            queryStringBuilder.Append(Lname);
            queryStringBuilder.Append("','");
            queryStringBuilder.Append(HomePhone + "','" + Mobile + "','" + Email + "','" + Address);
            queryStringBuilder.Append("','");
            queryStringBuilder.Append(Login + "','" + Password + "'");

            queryStringBuilder.Append(")");

            string queryString = queryStringBuilder.ToString();

            _hatData.UpdateData(queryString);
        }

        public string GetCustomerName(string Login, string Password)
        {
            object result = _hatData.GetSingleValue("SELECT FirstName FROM Customer WHERE Login = '" + Login + "'" + "AND Password = '" + Password + "'");
            string Name = result.ToString();
            return Name;

        }

        /// <summary>
        /// For Customer Shopping Account
        /// </summary>
        /// <param name="customerID"></param>
        /// <returns></returns>
        public DataTable GetCustomerOrderByCustomerID(string customerID)
        {

            string query = @"SELECT [Order].OrderID,[Order].OrderDate, OrderStatus.OrderStatus as [Status] ,SUM(OrderLine.Quantity * OrderLine.UnitPrice) as [Total], SUM(OrderLine.Quantity * OrderLine.UnitPrice)*0.15 as [GST]
                            , SUM(OrderLine.Quantity * OrderLine.UnitPrice)*0.15 + SUM(OrderLine.Quantity * OrderLine.UnitPrice) as [GrandTotal]
                            FROM ORDERSTATUS INNER JOIN ([ORDER] INNER JOIN OrderLine ON ORDER.OrderID = OrderLine.OrderID) ON ORDERSTATUS.StatusID = ORDER.StatusID
                            WHERE CustomerID = ?
                            GROUP BY [Order].OrderID, [Order].OrderDate, OrderStatus.OrderStatus
                            ORDER BY [Order].OrderDate DESC
                            ";
            OleDbParameter parCustomerID = new OleDbParameter("CustomerID", customerID);
            List<OleDbParameter> parameters = new List<OleDbParameter>();
            parameters.Add(parCustomerID);

            ErrorToken errorToken;
            DataTable result = _hatData.GetData(query, parameters, out errorToken);
            return result;
        }

        public void UpdateOrder(string orderId, string statusID)
        {

            StringBuilder sbquery = new StringBuilder("Update [ORDER] set [StatusID]=");
            sbquery.Append("'" + statusID + "'");

            sbquery.Append(" Where [OrderID]= ");
            sbquery.Append(orderId);
            string query = sbquery.ToString();
            _hatData.UpdateData(query);
     
        
        }


        public string AddOrder(string customerID, ShoppingCart cart, out ErrorToken token)
        {
            //Create Order
            string orderID = this.CreateOrder(customerID, out token);

            if (orderID == String.Empty)
            {
                _logger.WriteLog("Order for customer " + customerID + " could not be created. OrderID was not returned");
                return "Order could not be created. We have revealed the problem and be in contact with you soon.";
            }

            //Create order lines
            CreateOrderLines(orderID, cart);
            return String.Empty;
        }

        /// <summary>
        /// Create new order after checkout
        /// </summary>
        /// <param name="customerID"></param>
        /// <param name="token"></param>
        /// <returns></returns>
        private string CreateOrder(string customerID, out ErrorToken token)
        {
           
            string query = @"Insert into [ORDER] (CustomerID,OrderDate,StatusID) VALUES(?,?,?)";

            List<OleDbParameter> parameters = new List<OleDbParameter>();
            OleDbParameter customerIDPar = new OleDbParameter("CustomerID", OleDbType.Integer);
            customerIDPar.Value = customerID;
            parameters.Add(customerIDPar);
            OleDbParameter datePar = new OleDbParameter("OrderDate", OleDbType.Date);
            datePar.Value = DateTime.Now;
            parameters.Add(datePar);
            OleDbParameter statusIDPar = new OleDbParameter("StatusID", OleDbType.Integer);
            statusIDPar.Value = 1;
            parameters.Add(statusIDPar);

            _hatData.UpdateData(query, parameters, out token);

            query = @"SELECT MAX(OrderID) FROM [ORDER] WHERE CustomerID = " + customerID;

            object orderIDraw = _hatData.GetSingleValue(query);
            string orderID = String.Empty;
            if (orderIDraw != null)
            {
                orderID = orderIDraw.ToString();
            }
            return orderID;
        }


       /// <summary>
       /// create new record in Orderline after checkout
       /// </summary>
       /// <param name="orderID"></param>
       /// <param name="cart"></param>

        private void CreateOrderLines(string orderID, ShoppingCart cart)
        {
            foreach (DataRow row in cart.Content.Rows)
            {

                string query = @"INSERT INTO OrderLine (OrderID, ProductID, Quantity, Discount, UnitPrice, ColorID)
                            VALUES(" + orderID + ", " + row[ShoppingCart.FIELD_PRODUCT_ID].ToString() + ", "
                                             + row[ShoppingCart.FIELD_QUANTITY].ToString() + ", 0, "
                                             + row[ShoppingCart.FIELD_UNIT_PRICE].ToString() + ", "
                                             + row[ShoppingCart.FIELD_COLOR_ID].ToString() + ")";

                _hatData.UpdateData(query);
            }
        }

    }




        #endregion
}
