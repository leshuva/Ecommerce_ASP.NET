﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;
using System.Data;
using HatHelpers;

namespace DataLayer
{
    /// <summary>
    /// Data layer. Class is for connection with database
    /// </summary>
    /// 
    public class HatData
    {
       
        #region Fields
        private string _connectionString;
        private Logger _logger;
     
        #endregion


        #region Constructors
        public HatData(string connectionString, Logger logger)
        {
            _connectionString = connectionString;

            _logger = logger;
        }
        #endregion

        #region Database interaction methods


        public DataTable GetData(string sqlString, List<OleDbParameter> parameters, out ErrorToken token)
        {
            OleDbConnection conn = new OleDbConnection(_connectionString);
            DataTable result = new DataTable();
            token = null;
            try
            {
                conn.Open();
                OleDbCommand command = new OleDbCommand(sqlString, conn);

                if (parameters!= null && parameters.Any())
                {
                    command.Parameters.AddRange(parameters.ToArray());
                }

                OleDbDataAdapter da = new OleDbDataAdapter(command);
                da.Fill(result);

            }
            catch (Exception ex)
            {
                token = this.ProcessException("HatData.GetData - exception appeared: ", ex, sqlString, parameters);
            }
            finally
            {
                if (conn.State != ConnectionState.Closed)
                {
                    conn.Close();
                }
            }

            return result;
        }



        /// <summary>
        /// General method to update/insert/delete data sqlString can contain all the parameters
        /// </summary>
        /// <param name="sqlString"></param>
        public void UpdateData(string sqlString, List<OleDbParameter> parameters, out ErrorToken token)
        {
            token = null;
            OleDbConnection conn = new OleDbConnection(_connectionString);
            try
            {
                conn.Open();
                OleDbCommand command = new OleDbCommand(sqlString, conn);
                command.Parameters.AddRange(parameters.ToArray());

                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                token = this.ProcessException("HatData.UpdateData - exception appeared: ", ex, sqlString, parameters);
            }
            finally
            {
                if (conn.State != ConnectionState.Closed)
                {
                    conn.Close();
                }
            }
 
        }


        public object GetSingleValue(string sqlString, List<OleDbParameter> parameters, out ErrorToken token)
        {
            token = null;
            object result = new object();
            OleDbConnection conn = new OleDbConnection(_connectionString);
            try
            {
                conn.Open();
                OleDbCommand command = new OleDbCommand(sqlString, conn);

                command.Parameters.AddRange(parameters.ToArray());

                result = command.ExecuteScalar();
            }
            catch (Exception ex)
            {
                token = this.ProcessException("HatData.GetSingleValue - exception appeared: ", ex, sqlString, parameters);
            }
            finally
            {
                if (conn.State != ConnectionState.Closed)
                {
                    conn.Close();
                }
            }

            return result;
        }


        #endregion

        private ErrorToken ProcessException(string initialMessage, Exception ex, string sqlString, List<OleDbParameter> parameters)
        {
            StringBuilder sb = new StringBuilder(initialMessage + ex.GetType().ToString());
            sb.AppendLine("Exception message: " + ex.Message);
            sb.AppendLine("Sql command: " + sqlString);
            if (parameters != null && parameters.Any())
            {
                foreach (var parameter in parameters)
                {
                    sb.AppendLine(parameter.ParameterName + ": " + parameter.Value.ToString());
                }
            }

            _logger.WriteLog(sb.ToString());
            return new ErrorToken("", ex, sb.ToString());
        }

        #region obsolete 
        public DataTable GetData(string sqlString)
        {
            OleDbConnection conn = new OleDbConnection(_connectionString);
            DataTable result = new DataTable();
            try
            {
                conn.Open();
                OleDbCommand command = new OleDbCommand(sqlString, conn);

                OleDbDataAdapter da = new OleDbDataAdapter(command);
                da.Fill(result);

            }
            catch (Exception ex)
            {
                _logger.WriteLog("HatData.GetData - exception appeared: " + ex.GetType().ToString());
                _logger.WriteLog("Exception message: " + ex.Message);
                _logger.WriteLog("Sql command: " + sqlString);
            }
            finally
            {
                if (conn.State != ConnectionState.Closed)
                {
                    conn.Close();
                }
            }

            return result;
        }

        public void UpdateData(string sqlString)
        {
            OleDbConnection conn = new OleDbConnection(_connectionString);
            try
            {
                conn.Open();
                OleDbCommand command = new OleDbCommand(sqlString, conn);

                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                _logger.WriteLog("HatData.UpdateData - exception appeared: " + ex.GetType().ToString());
                _logger.WriteLog("Exception message: " + ex.Message);
                _logger.WriteLog("Sql command: " + sqlString);
            }
            finally
            {
                if (conn.State != ConnectionState.Closed)
                {
                    conn.Close();
                }
            }
        }


        public object GetSingleValue(string sqlString)
        {
            object result = new object();
            OleDbConnection conn = new OleDbConnection(_connectionString);
            try
            {
                conn.Open();
                OleDbCommand command = new OleDbCommand(sqlString, conn);

                result = command.ExecuteScalar();
            }
            catch (Exception ex)
            {
                _logger.WriteLog("HatData.GetSingleValue - exception appeared: " + ex.GetType().ToString());
                _logger.WriteLog("Exception message: " + ex.Message);
                _logger.WriteLog("Sql command: " + sqlString);
            }
            finally
            {
                if (conn.State != ConnectionState.Closed)
                {
                    conn.Close();
                }
            }

            return result;
        }

        #endregion

    }
}
