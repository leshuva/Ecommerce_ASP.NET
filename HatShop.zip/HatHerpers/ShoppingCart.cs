﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace HatHelpers
{
    /// <summary>
    /// Shopping cart is the class created for keeping information about shopping cart content
    /// </summary>
    public class ShoppingCart
    {
       
        public static readonly string FIELD_PRODUCT_ID = "ProductID";
        public static readonly string FIELD_PRODUCT_NAME = "Product";
        public static readonly string FIELD_CATEGORY = "Category";
        public static readonly string FIELD_COLOR_ID = "ColorID";
        public static readonly string FIELD_COLOR_NAME = "Color";
        public static readonly string FIELD_QUANTITY = "Quantity";
        public static readonly string FIELD_UNIT_PRICE = "UnitPrice";
        public static readonly string FIELD_SUB_TOTAL = "SubTotal";
        public static readonly string FIELD_TOTAL = "Total";

        private DataTable _cart;

        public double Total 
        {
            get
            {
                double result = 0;
                if (_cart == null)
                {
                    return result;
                }

                foreach (DataRow row in _cart.Rows)
                {
                    double subtotal;
                    if(Double.TryParse(row[FIELD_SUB_TOTAL].ToString(), out subtotal))
                    {
                        result += subtotal;
                    }
                }
                return result;
            }
        }

        public DataTable Content
        {
            get { return _cart; }
            
        }

        public ShoppingCart()
        {
            InitializeCart();
        }


        private void InitializeCart()
        {
            _cart = new DataTable("ShoppingCart");

            DataColumn productIdColumn = new DataColumn(FIELD_PRODUCT_ID);
            DataColumn productNameColumn = new DataColumn(FIELD_PRODUCT_NAME);
            DataColumn categoryColumn = new DataColumn(FIELD_CATEGORY);
            DataColumn colorIdColumn = new DataColumn(FIELD_COLOR_ID);
            DataColumn colorNameColumn = new DataColumn(FIELD_COLOR_NAME);
            DataColumn quantityColumn = new DataColumn(FIELD_QUANTITY, typeof(int));
            DataColumn unitPriceColumn = new DataColumn(FIELD_UNIT_PRICE, typeof(double));
            DataColumn subTotalColumn = new DataColumn(FIELD_SUB_TOTAL, typeof(double));
            DataColumn totalColumn = new DataColumn(FIELD_TOTAL, typeof(double));
            _cart.Columns.Add(productIdColumn);
            _cart.Columns.Add(productNameColumn);
            _cart.Columns.Add(categoryColumn);
            _cart.Columns.Add(colorIdColumn);
            _cart.Columns.Add(colorNameColumn);
            _cart.Columns.Add(quantityColumn);
            _cart.Columns.Add(unitPriceColumn);
            _cart.Columns.Add(subTotalColumn);
            _cart.Columns.Add(totalColumn);

        }


        public void AddProduct(string productID, string productName,string category, string colorID, string colorName, string unitPrice, string quantity)
        {
            foreach (DataRow row in Content.Rows)
            {
                if (row[ShoppingCart.FIELD_PRODUCT_ID].ToString() == productID && row[ShoppingCart.FIELD_COLOR_ID].ToString() == colorID)
                {
                    row[ShoppingCart.FIELD_QUANTITY] = Convert.ToInt32(row[ShoppingCart.FIELD_QUANTITY]) + Convert.ToInt32(quantity);

                    row[ShoppingCart.FIELD_SUB_TOTAL] = Convert.ToInt32(row[ShoppingCart.FIELD_QUANTITY]) * Convert.ToDouble(row[ShoppingCart.FIELD_UNIT_PRICE]);
                    
                    

                    return;
                }
            }

            DataRow newRow = Content.NewRow();
            newRow[ShoppingCart.FIELD_PRODUCT_ID] = productID;
            newRow[ShoppingCart.FIELD_PRODUCT_NAME] = productName;
            newRow[ShoppingCart.FIELD_CATEGORY] = category;
            newRow[ShoppingCart.FIELD_COLOR_ID] = colorID;
            newRow[ShoppingCart.FIELD_COLOR_NAME] = colorName;
            newRow[ShoppingCart.FIELD_UNIT_PRICE] = unitPrice;
            newRow[ShoppingCart.FIELD_QUANTITY] = Convert.ToInt32(quantity);

            newRow[ShoppingCart.FIELD_SUB_TOTAL] = Convert.ToInt32(newRow[ShoppingCart.FIELD_QUANTITY]) * Convert.ToDouble(newRow[ShoppingCart.FIELD_UNIT_PRICE]);
            
            Content.Rows.Add(newRow);
        }
    }
}
